import streamlit as st
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# --- Page Configuration ---
st.set_page_config(page_title="Translator", page_icon="🌍", layout="centered")

# --- Custom Styling ---
st.markdown(
    """
    <style>
        body {
            background-color: #f4f4f4;
        }
        .main-title {
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            color: #2E86C1;
        }
        .subtitle {
            text-align: center;
            font-size: 18px;
            color: #5D6D7E;
        }
        .stButton>button {
            background-color: #2E86C1;
            color: white;
            font-size: 16px;
            border-radius: 10px;
            width: 100%;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# --- Sidebar ---
st.sidebar.title("🔧 Settings")
theme = st.sidebar.radio("Choose Theme:", ["Light", "Dark"], index=0)

if theme == "Dark":
    st.markdown(
        """
        <style>
            body {background-color: #1E1E1E !important;}
            .main-title {color: #EAECEE !important;}
            .subtitle {color: #BDC3C7 !important;}
        </style>
        """,
        unsafe_allow_html=True,
    )

st.sidebar.write("### ℹ️ How to Use:")
st.sidebar.write("1. Enter your German text in the input box.")
st.sidebar.write("2. Click 'Translate' to generate the French translation.")
st.sidebar.write("3. View the output below.")

# --- Title & Subtitle ---
st.markdown('<p class="main-title">📚 German-to-French Translator</p>', unsafe_allow_html=True)
st.markdown('<p class="subtitle">AI-powered translation using Qwen Model</p>', unsafe_allow_html=True)

# --- Load Model ---
@st.cache_resource()
def load_model():
    model_name = "Qwen/Qwen2-1.5B"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype="auto")
    return tokenizer, model

tokenizer, model = load_model()

# --- User Input ---
user_input = st.text_area("✏️ Enter German Text:", height=150)

# --- Translation Button ---
if st.button("Translate to French") and user_input:
    with st.spinner("Translating... ⏳"):
        prompt = f"Translate the following German text into French:\n\n{user_input}\n\nFrench Translation:"
        inputs = tokenizer(prompt, return_tensors="pt")

        with torch.no_grad():
            output_tokens = model.generate(
                **inputs,
                max_new_tokens=100,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id
            )

        generated_text = tokenizer.decode(output_tokens[0], skip_special_tokens=True)

        # Extract translated text
        translation_start = generated_text.find("French Translation:") + len("French Translation:")
        translated_text = generated_text[translation_start:].strip()

    # --- Display Translation ---
    st.success("✅ Translation Complete!")
    st.text_area("📖 French Translation:", translated_text, height=150)
